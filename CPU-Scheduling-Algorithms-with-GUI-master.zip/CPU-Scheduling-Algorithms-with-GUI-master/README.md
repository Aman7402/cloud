# CPU-Scheduling-Algorithms-with-GUI
This project aims to implement the various CPU scheduling algorithms and display a GUI with all the algorithms, so that the user can select the algorithm which he/she wants to execute by giving the arrival time and the process time. The user can add or delete the number of processes. After the calculation, a Gantt chart is displayed with the processes, also a final table with processes, arrival time, total burst time, completion time, turnaround time, waiting time and response time is displayed to the user.

